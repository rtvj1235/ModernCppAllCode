#include <iostream>
#include "Functionalities.h"
#include "Bill.h"
#include "Invoice.h"

int main(){
    Container data;
    CreateObjects(data);
    std::cout<<BillAmountGivenBillNumber(data,"102IV")<<"\n";
    // std::cout<<"hello";
    std::cout<<FindHighestBillAmountInvoiceNumber(data)<<"\n";
}