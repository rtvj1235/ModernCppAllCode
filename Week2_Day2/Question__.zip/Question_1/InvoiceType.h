#ifndef INVOICETYPE_H
#define INVOICETYPE_H

#include <iostream>

enum class InvoiceType{
    E_BILL,
    PAPER_SLIP,
    SMS_GENRATED
};

#endif // INVOICETYPE_H
