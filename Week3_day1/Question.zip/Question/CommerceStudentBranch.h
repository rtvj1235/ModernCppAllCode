#ifndef COMMERCESTUDENTBRANCH_H
#define COMMERCESTUDENTBRANCH_H

#include <iostream>
enum class CommerceStudentBranch{
    FINANCE,
    BANKING,
    MM,
    CS,
    CA
};

#endif // COMMERCESTUDENTBRANCH_H
