#ifndef ENGINEERINGSTUDENTBRANCH_H
#define ENGINEERINGSTUDENTBRANCH_H

#include <iostream>

enum class EngineeringStudentBranch{
    CS,
    MECH,
    CIVIL,
    IT,
    ECE,
    ELECTRONICS

};

#endif // ENGINEERINGSTUDENTBRANCH_H
