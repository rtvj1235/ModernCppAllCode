#include <iostream>

#include "Functionalities.h"

int main(){
    Student s1(1,"akshay",20.0f);
    Student s2(4,"akshay",30.0f);
    Student s3(3,"akshay",40.0f);
    Student s4(2,"akshay",50.0f);
    std::cout<<Add<Student>(s1,s2,s3,s4)<<"\n";
    std::cout<<subtract<Student>(s1,s2,s3,s4)<<"\n";

    Employee e1(1,"a",1);
    Employee e2(2,"b",2);
    Employee e3(3,"c",3);
    Employee e4(4,"d",4);
    Employee e5(5,"e",5);
    std::cout<<Add<Employee>(e1,e2,e3,e4)<<"\n";
    std::cout<<subtract<Employee>(e1,e2,e3,e4)<<"\n";

}